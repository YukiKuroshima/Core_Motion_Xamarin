This is the sample code for the iOS recipe for using CoreMotion with the accelerometer.

[See the recipe at developer.xamarin.com](http://developer.xamarin.com/recipes/ios/input/accelerometer/use_coremotion_with_accelerometer/)
